package Assignment_2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;


public class MatrixGenerator {

	public static void main(String[] args) {
		
		// Define the matrix dimensions
		int rows = 1000;
		int cols = 1000;

		// Generate and display the random matrix
		double[][] randomMatrix1 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix1);
		double[][] randomMatrix2 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix2);
		
		// Multiply the matrices
		double[][] resultMatrix = multiplyMatrices(randomMatrix1, randomMatrix2);
		
		// Display 1st multiplied Matrix
		displayMatrix(resultMatrix);
		
		// Generate and display another Matrix
		double[][] randomMatrix3 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix3);
		
		//Multiply 1st result by the random matrix
		double[][] result_two_Matrix = multiplyMatrices(resultMatrix, randomMatrix3);
		
		// Display 2nd Multiplication of Matrix
		System.out.println("2nd Matrix starts here");
		displayMatrix(result_two_Matrix);
		
		// Generate and display final matrix
		double[][] randomMatrix4 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix4);
		
		// Multiply last set of matrixes 
		double[][] final_Result_Matrix = multiplyMatrices(result_two_Matrix, randomMatrix4);
		
		// Display last matrix multiplication
		System.out.println("3rd Matrix starts here");
		displayMatrix(final_Result_Matrix);
		
	}


	private static double[][] multiplyMatrices(double[][] randomMatrixA, double[][] randomMatrixB) {
		int rowsA = randomMatrixA.length;
	    int colsA = randomMatrixA[0].length;
	    int rowsB = randomMatrixB.length;
	    int colsB = randomMatrixB[0].length;

	    if (colsA != rowsB) {
	        throw new IllegalArgumentException("Matrix dimensions are not compatible for multiplication");
	    }

	    double[][] resultMatrix = new double[rowsA][colsB];

	    for (int i = 0; i < rowsA; i++) {
	        for (int j = 0; j < colsB; j++) {
	            for (int k = 0; k < colsA; k++) {
	                resultMatrix[i][j] += randomMatrixA[i][k] * randomMatrixB[k][j];
	            }
	        }
	    }

	    return resultMatrix;
	}


	// Function to generate a random matrix of the specified dimensions
	private static double[][] generateRandomMatrix(int rows, int cols) {
		double[][] matrix = new double[rows][cols];
		Random random = new Random();

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				matrix[i][j] = random.nextDouble();
			}
		}

		return matrix;
	}

	// Function to display the matrix
	private static void displayMatrix(double[][] matrix) {
		// Adjust the loop limits if you want to display only a subset of the matrix
		for (int i = 0; i < matrix.length && i < 1000; i++) {
			for (int j = 0; j < matrix[i].length && j < 1000; j++) {
				System.out.printf("%.4f\t", matrix[i][j]);
			}
			System.out.println();
		}

	}

}
