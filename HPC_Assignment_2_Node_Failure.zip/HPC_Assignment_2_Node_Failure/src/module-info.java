/**
 * 
 */
/**
 * 
 */
module HPC_Assignment_2_Node_Failure {
}