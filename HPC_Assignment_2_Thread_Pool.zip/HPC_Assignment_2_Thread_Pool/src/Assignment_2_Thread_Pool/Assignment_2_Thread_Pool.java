package Assignment_2_Thread_Pool;

import java.util.Random;

public class Assignment_2_Thread_Pool {

	public static void main(String[] args) {
		// Define the matrix dimensions
		int rows = 1000;
		int cols = 1000;

		// Generate and display the random matrices
		double[][] randomMatrix1 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix1);
		double[][] randomMatrix2 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix2);

		// Get the number of threads from the user
		int numThreads = getNumberOfThreads();

		// Multiply the matrices using the specified number of threads in a simulated distributed environment
		double[][] resultMatrix = multiplyMatricesWithDistributedThreads(randomMatrix1, randomMatrix2, numThreads);

		// Display the multiplied matrix
		displayMatrix(resultMatrix);

		// Generate and display another Matrix
		double[][] randomMatrix3 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix3);

		//Multiply 1st result by the random matrix
		double[][] result_two_Matrix = multiplyMatricesWithDistributedThreads(resultMatrix, randomMatrix3, numThreads);

		// Display 2nd Multiplication of Matrix
		System.out.println("2nd Matrix starts here");
		displayMatrix(result_two_Matrix);

		// Generate and display final matrix
		double[][] randomMatrix4 = generateRandomMatrix(rows, cols);
		displayMatrix(randomMatrix4);

		// Multiply last set of matrixes 
		double[][] final_Result_Matrix = multiplyMatricesWithDistributedThreads(result_two_Matrix, randomMatrix4, numThreads);

		// Display last matrix multiplication
		System.out.println("3rd Matrix starts here");
		displayMatrix(final_Result_Matrix);

	}

	private static int getNumberOfThreads() {
		// In a distributed environment, this step could involve communicating with a centralized configuration service
		// to determine the appropriate number of threads based on available resources and workload.
		// For simplicity, we'll use a constant value here.
		int num = 4;
		return num;
	}

	private static double[][] multiplyMatricesWithDistributedThreads(double[][] randomMatrixA, double[][] randomMatrixB, int numThreads) {
		int rowsA = randomMatrixA.length;
		int colsA = randomMatrixA[0].length;
		int rowsB = randomMatrixB.length;
		int colsB = randomMatrixB[0].length;

		if (colsA != rowsB) {
			throw new IllegalArgumentException("Matrix dimensions are not compatible for multiplication");
		}

		double[][] resultMatrix = new double[rowsA][colsB];

		Thread[] threads = new Thread[numThreads];

		for (int i = 0; i < numThreads; i++) {
			final int row = i;

			threads[i] = new Thread(() -> {
				for (int col = 0; col < colsB; col++) {
					for (int k = 0; k < colsA; k++) {
						resultMatrix[row][col] += randomMatrixA[row][k] * randomMatrixB[k][col];
					}
				}
				simulateDelay(200);  // Simulate communication delay or remote execution time
			});

			threads[i].start();
		}

		// Wait for all threads to finish
		try {
			for (Thread thread : threads) {
				thread.join();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return resultMatrix;
	}

	private static void simulateDelay(int milliseconds) {
		// Simulate delay to reflect communication or remote execution time
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	private static double[][] generateRandomMatrix(int rows, int cols) {
		double[][] matrix = new double[rows][cols];
		Random random = new Random();

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				matrix[i][j] = random.nextDouble();
			}
		}

		return matrix;
	}

	private static void displayMatrix(double[][] matrix) {
		for (int i = 0; i < matrix.length && i < 1000; i++) {
			for (int j = 0; j < matrix[i].length && j < 1000; j++) {
				System.out.printf("%.4f\t", matrix[i][j]);
			}
			System.out.println();
		}
		System.out.println("...");
	}
}
